<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { ArrowUp, ArrowUpRight, Activity, ChartNoAxesCombined, CircleDot, Menu, Moon, Sun, Users, Sparkles, X } from 'lucide-vue-next'
import ConversationSidebar from './components/ConversationSidebar.vue'
import ChatTurn from './components/ChatTurn.vue'
import ResearchPlayers from './components/ResearchPlayers.vue'
import { useChat } from './composables/useChat'

const chat = useChat()
const { selectedPlayers, sessions, turns, sessionId, title, sending, loadingSession, loadingHistory, historyError, error, busy, deletingId, deleteError } = chat
const draft = ref('')
const canSend = computed(() => !busy.value && !!draft.value.trim())
const sidebarOpen = ref(false)
const dark = ref(true)
const composer = ref<HTMLTextAreaElement>()
const scrollArea = ref<HTMLElement>()
const menuButton = ref<HTMLButtonElement>()
const mobileViewport = window.matchMedia('(max-width: 900px)')
function onViewportChange(event: MediaQueryListEvent) { if (!event.matches) sidebarOpen.value = false }
const prompts = [
  { icon: Users, label: 'Review a career claim', text: 'Rate, accumulation and relative efficiency.', prompt: 'Assess the claim that Michael Jordan was a stronger scorer than LeBron James over their entire NBA careers. Compare regular-season and playoff scoring volume and efficiency, efficiency relative to each season’s league, and bounded teammate and Finals-opponent context. Use completed seasons only. Give a conditional judgement, not an overall-player ranking.' },
  { icon: ChartNoAxesCombined, label: 'Test equal scoring windows', text: 'Same duration. Transparent criteria.', prompt: 'Assess whether Kobe Bryant’s scoring in 2005-06 through 2007-08 was stronger than Stephen Curry’s scoring in 2014-15 through 2016-17. Compare equal three-season windows, regular-season scoring volume, raw shooting efficiency and contemporaneous league-relative efficiency. Show which metric advantages change with the statistical lens.' },
  { icon: Activity, label: 'Check postseason scoring', text: 'Keep regular seasons and playoffs distinct.', prompt: 'Assess the claim that Michael Jordan had stronger postseason scoring than LeBron James. Compare Jordan’s 1990-91 through 1992-93 with James’s 2011-12 through 2013-14, using postseason points per game, true shooting and their changes from the corresponding regular seasons. Limit conclusions to these equal three-season samples.' },
  { icon: CircleDot, label: 'Investigate helper samples', text: 'Check whether the first sample is sufficient.', prompt: "Assess the claim that Michael Jordan’s scoring in 1990-91 was stronger than LeBron James’s scoring in 2014-15. Compare regular-season and playoff scoring volume and shooting efficiency relative to the league. Compare teammates: core helpers first, then rotation scoring, minutes and recorded games. Check whether the per-game helper leaders adequately represent the supporting cast’s recorded availability. Keep original samples and qualify any limited context." },
]

function syncTheme() {
  document.documentElement.classList.toggle('dark', dark.value)
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark.value ? '#101828' : '#ffffff')
}
function toggleTheme() {
  dark.value = !dark.value; syncTheme()
  try { localStorage.setItem('game-lab-theme', dark.value ? 'dark' : 'light') } catch { /* Theme remains usable with storage disabled. */ }
}
async function resizeComposer() {
  await nextTick()
  if (composer.value) { composer.value.style.height = 'auto'; composer.value.style.height = `${Math.min(composer.value.scrollHeight, 156)}px` }
}
watch(draft, resizeComposer)
async function scrollToEnd() {
  await nextTick()
  if (scrollArea.value && !loadingSession.value) {
    if (turns.value.at(-1)?.research_flow && !sending.value) {
      const flow = scrollArea.value.querySelector<HTMLElement>('.chat-turn:last-child .research-flow')
      if (flow) { scrollArea.value.scrollTop += flow.getBoundingClientRect().top - scrollArea.value.getBoundingClientRect().top - 20; return }
    }
    scrollArea.value.scrollTop = turns.value.length ? scrollArea.value.scrollHeight : 0
  }
}
watch(() => [turns.value.length, sending.value, loadingSession.value], scrollToEnd)
function closeSidebar() { sidebarOpen.value = false; nextTick(() => menuButton.value?.focus()) }
async function toggleSidebar() {
  sidebarOpen.value = !sidebarOpen.value
  if (sidebarOpen.value) { await nextTick(); document.querySelector<HTMLButtonElement>('#conversation-sidebar .mobile-only')?.focus() }
}
function keyboard(event: KeyboardEvent) {
  if (!sidebarOpen.value) return
  if (event.key === 'Escape') { event.preventDefault(); closeSidebar() }
  if (event.key === 'Tab') {
    const items = [...document.querySelectorAll<HTMLElement>('#conversation-sidebar button:not(:disabled), #conversation-sidebar input')].filter(el => el.getClientRects().length)
    const first = items[0], last = items[items.length - 1]
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus() }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
  }
}
function newChat() {
  chat.newChat(); draft.value = ''; sidebarOpen.value = false
  nextTick(() => {
    if (scrollArea.value) scrollArea.value.scrollTop = 0
    composer.value?.focus({ preventScroll: true })
  })
}
async function openSession(id: string) {
  if (await chat.openSession(id)) { draft.value = ''; sidebarOpen.value = false; await scrollToEnd() }
}
async function deleteSession(id: string) {
  const wasActive = sessionId.value === id
  if (await chat.deleteSession(id)) {
    if (wasActive) draft.value = ''
    await nextTick()
    document.querySelector<HTMLButtonElement>('#conversation-sidebar .new-chat')?.focus()
  }
}
function choosePrompt(prompt: string) { draft.value = prompt; composer.value?.focus() }
async function submit() {
  if (!canSend.value) return
  const text = draft.value; draft.value = ''
  await chat.send(text)
  composer.value?.focus()
}
function onEnter(event: KeyboardEvent) {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); void submit() }
}
async function retry(index: number) {
  if (busy.value) return
  const message = turns.value[index].message
  turns.value.splice(index, 1)
  await chat.send(message)
}
onMounted(() => {
  try { dark.value = localStorage.getItem('game-lab-theme') !== 'light' } catch { /* Default to dark. */ }
  syncTheme(); void chat.refreshHistory()
  document.addEventListener('keydown', keyboard)
  mobileViewport.addEventListener('change', onViewportChange)
})
onBeforeUnmount(() => {
  document.removeEventListener('keydown', keyboard)
  mobileViewport.removeEventListener('change', onViewportChange)
})
</script>

<template>
  <div class="app-shell">
    <button v-if="sidebarOpen" class="sidebar-backdrop" aria-label="Close conversation history" tabindex="-1" @click="closeSidebar"></button>
    <ConversationSidebar :sessions="sessions" :active-id="sessionId" :busy="busy" :loading="loadingHistory" :error="historyError" :open="sidebarOpen" :deleting-id="deletingId" :delete-error="deleteError" @new="newChat" @select="openSession" @delete="deleteSession" @close="closeSidebar" @refresh="chat.refreshHistory" />
    <main class="main-panel" :inert="sidebarOpen || undefined">
      <header class="conversation-header">
        <button ref="menuButton" class="icon-button mobile-only" aria-label="Open conversation history" aria-controls="conversation-sidebar" :aria-expanded="sidebarOpen" @click="toggleSidebar"><Menu :size="21" /></button>
        <div class="conversation-heading"><span class="section-kicker">SCORING CLAIM REVIEW</span><h1>{{ title }}</h1></div>
        <div class="conversation-actions"><span class="source-badge"><span></span> NBA API evidence</span><button class="icon-button" :aria-label="dark ? 'Switch to light theme' : 'Switch to dark theme'" @click="toggleTheme"><Sun v-if="dark" :size="19" /><Moon v-else :size="19" /></button></div>
      </header>
      <div v-if="error" class="page-error" role="alert">{{ error }}<button class="icon-button" aria-label="Dismiss error" @click="error = ''"><X :size="16" /></button></div>
      <div ref="scrollArea" class="conversation-scroll" :aria-busy="busy">
        <div v-if="loadingSession" class="session-loading" role="status">Opening your conversation…</div>
        <section v-if="!loadingSession && !turns.length" class="welcome">
          <div class="hero-art" aria-hidden="true"><svg viewBox="0 0 500 400"><g fill="none" stroke="currentColor" stroke-width="1"><rect x="60" y="35" width="330" height="380" rx="4"/><path d="M60 225h330M163 35v95h124V35M181 35v76h88V35"/><circle cx="225" cy="225" r="48"/><path d="M163 130a62 62 0 0 0 124 0M94 35v40a131 131 0 0 0 262 0V35"/><circle cx="225" cy="58" r="9"/><path d="M201 46h48"/></g></svg></div>
          <div class="welcome-eyebrow"><span class="tiny-line"></span> CROSS-ERA NBA SCORING</div>
          <div class="hero-mark"><img src="/favicon.svg" width="54" height="54" alt="" /><span class="sparkle"><Sparkles :size="14" /></span></div>
          <h2>Does the claim<br /><span>hold up?</span></h2>
          <p class="welcome-description">For fans and analysts comparing scorers across eras.<br />Name two players and a scoring claim. A research team tests the evidence, counterexamples and limits.</p>
          <div class="prompt-heading"><span>MAKE YOUR FIRST PLAY</span><span>Start with an idea <ArrowUpRight :size="14" /></span></div>
          <div class="prompt-grid"><button v-for="(prompt, index) in prompts" :key="prompt.label" class="prompt-card" @click="choosePrompt(prompt.prompt)"><span class="prompt-icon" :class="`prompt-icon-${index}`"><component :is="prompt.icon" :size="21" /></span><span class="prompt-copy"><strong>{{ prompt.label }}</strong><span>{{ prompt.text }}</span></span><ArrowUpRight class="prompt-arrow" :size="17" /></button></div>
          <div class="welcome-footnote"><span class="tiny-dot"></span> Careers or equal season windows · 1984-85 onward · Completed seasons only</div>
        </section>
        <div v-else-if="!loadingSession && turns.length" class="message-list" aria-live="polite" aria-relevant="additions text"><ChatTurn v-for="(turn, index) in turns" :key="index" :turn="turn" :pending="sending && index === turns.length - 1 && !turn.response" @retry="retry(index)" @resolve="chat.send(turn.message, $event)" :can-resolve="!busy && index === turns.length - 1" /></div>
      </div>
      <footer class="composer-area">
        <ResearchPlayers v-model="selectedPlayers" :disabled="busy" />
        <form class="composer-box" @submit.prevent="submit">
          <label for="message" class="sr-only">Your message</label>
          <textarea id="message" ref="composer" v-model="draft" rows="1" maxlength="12000" placeholder="State a scoring claim, name two players, and choose careers or season windows…" :disabled="loadingSession" @keydown="onEnter"></textarea>
          <div class="composer-bottom"><div class="composer-settings"><span class="composer-mode"><Sparkles :size="15" /> Scoring Review<span class="mode-pill">RESEARCH</span></span></div><div class="send-controls"><span class="enter-hint">↵ to send</span><button class="send-button" type="submit" :disabled="!canSend" aria-label="Send message"><ArrowUp :size="21" /></button></div></div>
        </form>
        <p class="composer-disclaimer">AI can make mistakes. Inspect the evidence and scope.<span>Shift + Enter for a new line</span></p>
      </footer>
    </main>
  </div>
</template>
